import React, { useEffect, useState } from "react";
import "./Banner.css";

export default function Banner() {
  const [loaded, setLoaded] = useState(false);

  // Trigger animation after mount
  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section id="home" className="w-full py-10">
      <div className="container-fluid relative mx-auto p-[20px] lg:pl-[60px] flex flex-col-reverse lg:flex-row items-center justify-between gap-8 banner-right">
        {/* Left Section: Content */}
        <div
          className="flex-1 text-center lg:text-left z-10"
          data-aos="fade-right"
          data-aos-delay="500"
          data-aos-offset="500"
        >
          <button className="gradient-border-btn px-[15px] py-[10px] text-[#EEF2FF] font-semibold transition duration-300">
            Pay Smart. Pay Fast
          </button>
          <h1 className="leading-[1.2] mt-[20px] text-[55px] font-medium bg-gradient-to-r from-white to-[rgba(189,160,255,0.75)] bg-clip-text text-transparent">
            End-to-End Payout & Payroll Solutions for Digital Era.
          </h1>
          <p className="text-[#B5B0B7] mt-[20px] mb-[40px] text-[18px] leading-[1.5] lg:max-w-md">
            Optimize transactions and payouts with our secure, efficient payment
            gateway solution, ensuring smooth operations.
          </p>
          <div className="space-x-4 flex justify-center lg:justify-start">
            <button className="gradient-border-btn px-[15px] py-[10px] text-[#EEF2FF] font-semibold transition duration-300 flex">
              Reach out
              <img
                src="/images/Chevron-Right.svg"
                alt="Icon"
                className="w-[16px] h-auto ml-[10px]"
              />
            </button>
            <button className="gradient-border-btn px-[15px] py-[10px] text-[#EEF2FF] font-semibold transition duration-300 flex">
              Get Started
              <img
                src="/images/Chevron-Right.svg"
                alt="Icon"
                className="w-[16px] h-auto ml-[10px]"
              />
            </button>
          </div>
        </div>

        {/* Right Section: Image + Floating Buttons */}
        <div
          className="flex-1 relative w-full max-w-3xl mx-auto"
          data-aos="fade-left"
        >
          <img
            src="/images/Hero-Banner.png"
            alt="Banner"
            className="w-full h-auto rounded-lg shadow-md"
          />

          {/* Floating Buttons with animation */}
          <button
            className={`banner-btn absolute top-[110px] right-4 bg-white p-2 rounded-lg shadow-md hover:scale-110 text-white transition-transform duration-300 ${
              loaded ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-5"
            }`}
          >
            Sales Product Screening
          </button>
          <button
            className={`banner-btn text-white absolute top-1/2 left-[110px] mt-4 transform -translate-y-1/2 bg-white p-2 rounded-lg shadow-md hover:scale-110 transition-transform duration-300 ${
              loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-x-5"
            }`}
          >
            Payout Process
          </button>
          <button
            className={`banner-btn text-white absolute top-1/2 right-4 transform -translate-x-1/2 bg-white p-2 rounded-lg shadow-md hover:scale-110 transition-transform duration-300 ${
              loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"
            }`}
          >
            Transactions
          </button>
        </div>
      </div>
    </section>
  );
}
