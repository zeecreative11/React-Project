import React from "react";
import "./ContentSection.css";

export default function ContentSection() {
  return (
    <section
      id="ai-banking"
      className="w-full py-[60px] lg:py-[120px] pb-[200px]"
      data-aos="fade-up"
      data-aos-delay="500"
      data-aos-offset="500"
    >
      <div className="container-fluid mx-auto lg:pl-[60px] md:p-[20px] flex flex-col-reverse md:flex-row items-center justify-between gap-10">
        {/* Left Content */}
        <div className="flex-1 text-center md:text-left animate-fadeInLeft relative content-left">
          <button className="gradient-border-btn px-[15px] py-[10px] text-[#EEF2FF] font-semibold transition duration-300">
            Reliable, and Efficient
          </button>
          <h2 className="text-[40px] font-semibold text-white mt-[35px] mb-[14px] max-w-sm">
            Simplify the payments process
          </h2>
          <p className="text-white text-[16px]">
            Tools crafted to simplify and enhance your payout processes.
          </p>
        </div>

        {/* Right Image */}
        <div className="flex-1 animate-fadeInRight">
          <img
            src="/images/Content-Right.png"
            alt="AI Banking"
            className="w-full max-w-md mx-auto"
          />
        </div>
      </div>
    </section>
  );
}
