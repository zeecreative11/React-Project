import React, { useEffect, useState } from "react";

const Preloader = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  if (!loading) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black text-white">
      {/* Spinner */}
      <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-cyan-400 mb-6"></div>

      {/* Animated Gradient Text */}
      <h1
        className="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-fuchsia-500 to-yellow-400 
          bg-clip-text text-transparent bg-[length:200%_200%] animate-move-bg"
      >
        UzOPay
      </h1>
    </div>
  );
};

export default Preloader;
