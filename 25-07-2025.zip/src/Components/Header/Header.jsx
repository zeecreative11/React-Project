import React, { useState } from "react";
import "./Header.css";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const menuItems = [
    { label: "Home", target: "#home" },
    { label: "AI Banking", target: "#ai-banking" },
    { label: "Payments", target: "#payments" },
    { label: "Payouts", target: "#payouts" },
    { label: "Payroll", target: "#payroll" },
    { label: "Contact Us", target: "#contact" },
  ];

  return (
    <header
      data-aos="fade-down"
      className="text-white p-[20px] shadow-md"
      style={{
        backgroundImage: "url('/images/Header-Bg.png')",
        backgroundPosition: "center bottom -100px",
      }}
    >
      <div className="max-w-[960px] mx-auto pt-[14px] pb-[14px] flex items-center justify-between rounded-full border-customCyan border-2 px-9">
        {/* Logo */}
        <div className="flex items-center py-2">
          {/* <img src="/logo.png" alt="Logo" className="h-10 w-auto mr-2" /> */}
          <span className="text-xl font-bold">UzOPay</span>
        </div>

        {/* Hamburger for mobile */}
        <div className="md:hidden">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="focus:outline-none"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              {isOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              )}
            </svg>
          </button>
        </div>

        {/* Menu - hidden on small screens */}
        <nav className="hidden md:flex space-x-7">
          {menuItems.map((item, index) => (
            <a
              key={index}
              href={item.target}
              className="hover:text-customCyan transition-colors duration-300"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-blue-800 px-4 pb-4">
          {menuItems.map((item, index) => (
            <a
              key={index}
              href="#"
              className="block py-2 text-white border-b border-blue-700 hover:text-gray-300"
            >
              {item}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}
