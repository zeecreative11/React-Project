import AOS from "aos";
import "aos/dist/aos.css";
import { useEffect } from "react";
import "./App.css";
import Header from "./Components/Header/Header";
import Banner from "./Components/Banner/Banner";
import ContentSection from "./Components/ContentSection/ContentSection";
import Preloader from "./Components/Preloader/Preloader";

function App() {
  useEffect(() => {
    AOS.init({ duration: 800, once: true, easing: "ease-in-out" });
  }, []);
  return (
    <>
      <Preloader />
      <Header />
      <Banner />
      <ContentSection />
    </>
  );
}

export default App;
