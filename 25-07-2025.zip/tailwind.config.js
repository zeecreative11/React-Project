/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        customCyan: "#33C4FF",
        bgColor: "#010203",
      },
      backgroundSize: {
        "200%": "200% 200%",
      },
      animation: {
        "move-bg": "moveBackground 3s linear infinite",
      },
      keyframes: {
        moveBackground: {
          "0%": { backgroundPosition: "0% 50%" },
          "100%": { backgroundPosition: "100% 50%" },
        },
      },
    },
  },
  plugins: [],
};
